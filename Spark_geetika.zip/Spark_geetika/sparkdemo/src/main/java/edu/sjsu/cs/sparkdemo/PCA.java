package edu.sjsu.cs.sparkdemo;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.apache.spark.api.java.*;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.mllib.linalg.distributed.RowMatrix;
import org.apache.spark.mllib.linalg.Matrix;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.Vectors;
import org.apache.spark.rdd.RDD;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;

public class PCA {
  public static void main(String[] args) {
    SparkConf conf = new SparkConf().setAppName("PCA Example");
    
    JavaSparkContext ctx = new JavaSparkContext(conf);
    JavaRDD<String> lines = ctx.textFile(args[0], 1);
    int principleComponents = Integer.parseInt(args[1]);
    
    int row = (int) lines.count();
    int columns = lines.first().split(",").length;
    
    double[][] array = new double[row][columns];  
    
    //Split the tokens
    List<String> tokens = lines.collect();
    Object[] arr = tokens.toArray();
    
    //Populate the array with Iris Data
    for(int i=0;i<arr.length;i++)
    {
	    String data = (String) arr[i];
	    String tarray[] = data.split(",");
	    for(int j=0;j<tarray.length-1;j++)
	    {
	    	array[i][j] = Double.parseDouble(tarray[j]);
	    }
    }
    
    
    LinkedList<Vector> rowsList = new LinkedList<Vector>();
    for (int i = 0; i < array.length; i++) {
      Vector currentRow = Vectors.dense(array[i]);
      rowsList.add(currentRow);
    }
    JavaRDD<Vector> rows = ctx.parallelize(rowsList);

    // Create a RowMatrix from JavaRDD<Vector>.
    RowMatrix mat = new RowMatrix(rows.rdd());

    // Compute the top 3 principal components.
    Matrix pc = mat.computePrincipalComponents(principleComponents);
    RowMatrix projected = mat.multiply(pc);
    
    projected.rows().saveAsTextFile(args[2]);;
    
    
  }
}
